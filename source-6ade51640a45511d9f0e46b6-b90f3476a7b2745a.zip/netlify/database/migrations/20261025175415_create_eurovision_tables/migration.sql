CREATE TABLE "contests" (
	"id" serial PRIMARY KEY,
	"year" integer NOT NULL UNIQUE,
	"host_city" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "entries" (
	"id" serial PRIMARY KEY,
	"show_id" integer NOT NULL,
	"start_number" integer NOT NULL,
	"song_id" integer
);
--> statement-breakpoint
CREATE TABLE "raters" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "ratings" (
	"id" serial PRIMARY KEY,
	"entry_id" integer NOT NULL,
	"rater_id" integer NOT NULL,
	"score" integer NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "shows" (
	"id" serial PRIMARY KEY,
	"contest_id" integer NOT NULL,
	"kind" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "songs" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"artist" text NOT NULL,
	"country" text NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE UNIQUE INDEX "entries_show_start_idx" ON "entries" ("show_id","start_number");--> statement-breakpoint
CREATE UNIQUE INDEX "ratings_entry_rater_idx" ON "ratings" ("entry_id","rater_id");--> statement-breakpoint
CREATE UNIQUE INDEX "shows_contest_kind_idx" ON "shows" ("contest_id","kind");--> statement-breakpoint
ALTER TABLE "entries" ADD CONSTRAINT "entries_show_id_shows_id_fkey" FOREIGN KEY ("show_id") REFERENCES "shows"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "entries" ADD CONSTRAINT "entries_song_id_songs_id_fkey" FOREIGN KEY ("song_id") REFERENCES "songs"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "ratings" ADD CONSTRAINT "ratings_entry_id_entries_id_fkey" FOREIGN KEY ("entry_id") REFERENCES "entries"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "ratings" ADD CONSTRAINT "ratings_rater_id_raters_id_fkey" FOREIGN KEY ("rater_id") REFERENCES "raters"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "shows" ADD CONSTRAINT "shows_contest_id_contests_id_fkey" FOREIGN KEY ("contest_id") REFERENCES "contests"("id") ON DELETE CASCADE;