-- Ratings moved from the Eurovision scale (1–8, 10, 12) to 1–10; earlier 12s become 10s.
UPDATE "ratings" SET "score" = 10 WHERE "score" > 10;
