CREATE TABLE "predictions" (
	"id" serial PRIMARY KEY,
	"entry_id" integer NOT NULL,
	"rater_id" integer NOT NULL,
	"place" integer NOT NULL,
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "entries" ADD COLUMN "final_place" integer;--> statement-breakpoint
CREATE UNIQUE INDEX "predictions_entry_rater_idx" ON "predictions" ("entry_id","rater_id");--> statement-breakpoint
ALTER TABLE "predictions" ADD CONSTRAINT "predictions_entry_id_entries_id_fkey" FOREIGN KEY ("entry_id") REFERENCES "entries"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "predictions" ADD CONSTRAINT "predictions_rater_id_raters_id_fkey" FOREIGN KEY ("rater_id") REFERENCES "raters"("id") ON DELETE CASCADE;