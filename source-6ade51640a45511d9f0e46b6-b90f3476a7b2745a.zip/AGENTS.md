# AGENTS.md

Eurovision Song Contest Scoreboard: a Eurovision rating app for a small friend group, built with TanStack Start on Netlify, with data in Netlify Database (Postgres) through Drizzle ORM.

## Data model (`db/schema.ts`)

- `raters` – jury members (no auth; the current rater is chosen in the header and stored in `localStorage` under `esc-rater-id`).
- `songs` – reusable library: title, artist, country.
- `contests` – one row per year (unique), optional host city.
- `shows` – three per contest, `kind` is `semi1 | semi2 | final` (see `src/lib/shows.ts`). Created together with the contest.
- `entries` – start numbers of a show (`start_number` unique per show), `song_id` nullable, `final_place` (actual finishing place within its show, semis and final; entered in the running order, also used by the points battle; places ≤ `QUALIFIERS` in a semi count as qualified).
- `ratings` – one per (entry, rater); `score` is 1–10 points (`POINTS`/`MAX_POINTS` in `src/lib/shows.ts`), plus `note`.
- `predictions` – points battle: one predicted Grand Final place per (entry, rater). Penalty is |predicted − actual|; fewest points wins (`components/points-battle.tsx`).

Ratings belong to a performance (entry), not a song: changing an entry's song or deleting a song deletes that entry's ratings, predictions and final place (handled in `setEntrySong` / `deleteSong`).

Migrations live in `netlify/database/migrations/` and are generated with `npx drizzle-kit generate --name <name>`. Never edit applied migrations; never run migrate/push.

## Key files

- `src/lib/eurovision.functions.ts` – all server functions (CRUD for raters, songs, contests, entries, ratings). Validate input with zod via `.validator()`.
- `src/lib/rater.tsx` – rater context, colours, initials.
- `src/lib/countries.ts` – Eurovision country list + flag codes; flags render as SVG images from `public/flags` via `components/flag.tsx` (emoji flags fail on Windows).
- `src/routes/__root.tsx` – shell, fonts, root loader for raters, header layout.
- `src/routes/index.tsx` – home: years list, new-year dialog.
- `src/routes/years.$year.tsx` – show tabs, running order, leaderboard.
- `src/routes/songs.tsx` – song library.
- `src/components/` – `site-header` (rater picker, friends dialog), `song-dialog`, `song-picker`, `score-chip`, `new-year-dialog`.

## Conventions

- Mutations call a server function, then `router.invalidate()` to reload loader data; failures show a `sonner` toast.
- Theme is a single dark "stage" palette in `src/styles.css`; extra tokens `gold`, `cyan` and the points scale `score-low`/`score-mid`/`score-high` (red → white → green, blended by `pointsStyle` in `score-chip.tsx`). Headings use Unbounded, body Manrope (Google Fonts in the root head).
- Use theme classes, not raw colours. Keep icon-only buttons labelled.
