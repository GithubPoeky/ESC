import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from 'drizzle-orm/pg-core'

// The people rating songs (the friend group).
export const raters = pgTable('raters', {
  id: serial().primaryKey(),
  name: text().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})

// Reusable song library: one entry per song, picked into start numbers.
export const songs = pgTable('songs', {
  id: serial().primaryKey(),
  title: text().notNull(),
  artist: text().notNull(),
  country: text().notNull(),
  createdAt: timestamp('created_at').defaultNow(),
})

// One Eurovision year.
export const contests = pgTable('contests', {
  id: serial().primaryKey(),
  year: integer().notNull().unique(),
  hostCity: text('host_city').notNull().default(''),
  createdAt: timestamp('created_at').defaultNow(),
})

// Shows of a year: 'semi1' | 'semi2' | 'final'.
export const shows = pgTable(
  'shows',
  {
    id: serial().primaryKey(),
    contestId: integer('contest_id')
      .notNull()
      .references(() => contests.id, { onDelete: 'cascade' }),
    kind: text().notNull(),
  },
  (t) => [uniqueIndex('shows_contest_kind_idx').on(t.contestId, t.kind)],
)

// A start number within a show, optionally filled with a song.
export const entries = pgTable(
  'entries',
  {
    id: serial().primaryKey(),
    showId: integer('show_id')
      .notNull()
      .references(() => shows.id, { onDelete: 'cascade' }),
    startNumber: integer('start_number').notNull(),
    songId: integer('song_id').references(() => songs.id, {
      onDelete: 'set null',
    }),
    // Actual finishing place within its show (semi or final), entered after it.
    finalPlace: integer('final_place'),
  },
  (t) => [uniqueIndex('entries_show_start_idx').on(t.showId, t.startNumber)],
)

// One score per rater per entry (performance).
export const ratings = pgTable(
  'ratings',
  {
    id: serial().primaryKey(),
    entryId: integer('entry_id')
      .notNull()
      .references(() => entries.id, { onDelete: 'cascade' }),
    raterId: integer('rater_id')
      .notNull()
      .references(() => raters.id, { onDelete: 'cascade' }),
    score: integer().notNull(),
    note: text().notNull().default(''),
    updatedAt: timestamp('updated_at').defaultNow(),
  },
  (t) => [uniqueIndex('ratings_entry_rater_idx').on(t.entryId, t.raterId)],
)

// Points battle: a rater's predicted finishing place for a Grand Final entry.
export const predictions = pgTable(
  'predictions',
  {
    id: serial().primaryKey(),
    entryId: integer('entry_id')
      .notNull()
      .references(() => entries.id, { onDelete: 'cascade' }),
    raterId: integer('rater_id')
      .notNull()
      .references(() => raters.id, { onDelete: 'cascade' }),
    place: integer().notNull(),
    updatedAt: timestamp('updated_at').defaultNow(),
  },
  (t) => [uniqueIndex('predictions_entry_rater_idx').on(t.entryId, t.raterId)],
)
