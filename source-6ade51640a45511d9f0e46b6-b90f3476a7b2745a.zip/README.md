# Douze Points Club

A private Eurovision Song Contest rating site for a small group of friends. Set up a contest year, fill the running order of both semi-finals and the Grand Final with songs from a shared library, and let every member of the jury hand out Eurovision-style points (1–8, 10, 12).

## Features

- **Contest years** – "New Eurovision year" creates Semi-final 1, Semi-final 2 and the Grand Final with a chosen number of empty start numbers (defaults 15 / 16 / 26). Start numbers can be added or removed later.
- **Song library** – each song is title, artist and country (with flag). Songs can be added on the Songs page or straight from a start number, then picked for any start number in any year.
- **Jury** – add the friends who rate, pick "who you are" in the header (remembered per device). Anyone's chip can be filled in, so one phone can collect the whole sofa's votes.
- **Ratings** – one score plus an optional note per juror per performance, with averages per start number.
- **Leaderboard** – per show ranking by total points, plus each juror's top pick.

## Tech

- TanStack Start (React 19, file-based routing, server functions)
- Netlify Database (managed Postgres) with Drizzle ORM
- Tailwind CSS 4 and shadcn/ui components
- Deployed on Netlify

## Running locally

```bash
pnpm install
netlify dev
```

`netlify dev` provides the local database emulation. Schema changes go in `db/schema.ts`, followed by:

```bash
npx drizzle-kit generate --name <describe_change>
```

Migrations in `netlify/database/migrations/` are applied automatically on deploy.

## Ideas for later

- Overall year view combining semi-final and final results
- Import a running order from a list
- Login for jurors (Netlify Identity) if the site ever needs to be private
