import { createServerFn } from '@tanstack/react-start'
import { and, asc, desc, eq, inArray, max, sql } from 'drizzle-orm'
import { z } from 'zod'

import { db } from '../../db/index.js'
import {
  contests,
  entries,
  predictions,
  raters,
  ratings,
  shows,
  songs,
} from '../../db/schema.js'
import { MAX_POINTS, SHOW_KINDS, type ShowKind } from './shows'

const id = z.number().int().positive()
const name = z.string().trim().min(1).max(120)

/* ---------------------------------- Raters --------------------------------- */

export const listRaters = createServerFn({ method: 'GET' }).handler(() =>
  db.select().from(raters).orderBy(asc(raters.id)),
)

export const createRater = createServerFn({ method: 'POST' })
  .validator(z.object({ name: name.max(40) }))
  .handler(async ({ data }) => {
    const [row] = await db.insert(raters).values(data).returning()
    return row
  })

export const renameRater = createServerFn({ method: 'POST' })
  .validator(z.object({ id, name: name.max(40) }))
  .handler(async ({ data }) => {
    await db.update(raters).set({ name: data.name }).where(eq(raters.id, data.id))
    return { ok: true }
  })

export const deleteRater = createServerFn({ method: 'POST' })
  .validator(z.object({ id }))
  .handler(async ({ data }) => {
    await db.delete(raters).where(eq(raters.id, data.id))
    return { ok: true }
  })

/* ---------------------------------- Songs ---------------------------------- */

const songInput = z.object({ title: name, artist: name, country: name })

export const listSongs = createServerFn({ method: 'GET' }).handler(async () => {
  const usage = db
    .select({
      songId: entries.songId,
      years: sql<string>`string_agg(distinct ${contests.year}::text, ',')`.as(
        'years',
      ),
    })
    .from(entries)
    .innerJoin(shows, eq(entries.showId, shows.id))
    .innerJoin(contests, eq(shows.contestId, contests.id))
    .groupBy(entries.songId)
    .as('usage')

  const rows = await db
    .select({
      id: songs.id,
      title: songs.title,
      artist: songs.artist,
      country: songs.country,
      years: usage.years,
    })
    .from(songs)
    .leftJoin(usage, eq(usage.songId, songs.id))
    .orderBy(asc(songs.country), asc(songs.title))

  return rows.map((r) => ({
    ...r,
    years: r.years ? r.years.split(',').map(Number).sort() : [],
  }))
})

export const createSong = createServerFn({ method: 'POST' })
  .validator(songInput)
  .handler(async ({ data }) => {
    const [row] = await db.insert(songs).values(data).returning()
    return row
  })

export const updateSong = createServerFn({ method: 'POST' })
  .validator(songInput.extend({ id }))
  .handler(async ({ data }) => {
    const { id: songId, ...rest } = data
    await db.update(songs).set(rest).where(eq(songs.id, songId))
    return { ok: true }
  })

export const deleteSong = createServerFn({ method: 'POST' })
  .validator(z.object({ id }))
  .handler(async ({ data }) => {
    // Ratings, predictions and results belong to a performance of this
    // song; drop them with it.
    const used = db
      .select({ id: entries.id })
      .from(entries)
      .where(eq(entries.songId, data.id))
    await db.delete(ratings).where(inArray(ratings.entryId, used))
    await db.delete(predictions).where(inArray(predictions.entryId, used))
    await db
      .update(entries)
      .set({ finalPlace: null })
      .where(eq(entries.songId, data.id))
    await db.delete(songs).where(eq(songs.id, data.id))
    return { ok: true }
  })

/* -------------------------------- Contests --------------------------------- */

export const listContests = createServerFn({ method: 'GET' }).handler(
  async () => {
    const rows = await db
      .select({
        id: contests.id,
        year: contests.year,
        hostCity: contests.hostCity,
        slots: sql<number>`count(${entries.id})::int`,
        filled: sql<number>`count(${entries.songId})::int`,
      })
      .from(contests)
      .leftJoin(shows, eq(shows.contestId, contests.id))
      .leftJoin(entries, eq(entries.showId, shows.id))
      .groupBy(contests.id)
      .orderBy(desc(contests.year))

    const ratingCounts = await db
      .select({
        contestId: shows.contestId,
        count: sql<number>`count(${ratings.id})::int`,
      })
      .from(ratings)
      .innerJoin(entries, eq(ratings.entryId, entries.id))
      .innerJoin(shows, eq(entries.showId, shows.id))
      .groupBy(shows.contestId)
    const byContest = new Map(ratingCounts.map((r) => [r.contestId, r.count]))

    return rows.map((r) => ({ ...r, ratings: byContest.get(r.id) ?? 0 }))
  },
)

const slotCount = z.number().int().min(0).max(60)

export const createContest = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      year: z.number().int().min(1956).max(2100),
      hostCity: z.string().trim().max(80),
      counts: z.object({ semi1: slotCount, semi2: slotCount, final: slotCount }),
    }),
  )
  .handler(async ({ data }) => {
    const [existing] = await db
      .select({ id: contests.id })
      .from(contests)
      .where(eq(contests.year, data.year))
    if (existing) throw new Error(`${data.year} already exists`)

    const [contest] = await db
      .insert(contests)
      .values({ year: data.year, hostCity: data.hostCity })
      .returning()

    try {
      const createdShows = await db
        .insert(shows)
        .values(SHOW_KINDS.map((kind) => ({ contestId: contest.id, kind })))
        .returning()

      const slots = createdShows.flatMap((show) =>
        Array.from(
          { length: data.counts[show.kind as ShowKind] },
          (_, i) => ({ showId: show.id, startNumber: i + 1 }),
        ),
      )
      if (slots.length) await db.insert(entries).values(slots)
    } catch (error) {
      await db.delete(contests).where(eq(contests.id, contest.id))
      throw error
    }
    return { year: contest.year }
  })

export const updateContest = createServerFn({ method: 'POST' })
  .validator(z.object({ id, hostCity: z.string().trim().max(80) }))
  .handler(async ({ data }) => {
    await db
      .update(contests)
      .set({ hostCity: data.hostCity })
      .where(eq(contests.id, data.id))
    return { ok: true }
  })

export const deleteContest = createServerFn({ method: 'POST' })
  .validator(z.object({ id }))
  .handler(async ({ data }) => {
    await db.delete(contests).where(eq(contests.id, data.id))
    return { ok: true }
  })

export const getContest = createServerFn({ method: 'GET' })
  .validator(z.object({ year: z.number().int() }))
  .handler(async ({ data }) => {
    const [contest] = await db
      .select()
      .from(contests)
      .where(eq(contests.year, data.year))
    if (!contest) return null

    const showRows = await db
      .select()
      .from(shows)
      .where(eq(shows.contestId, contest.id))
    const showIds = showRows.map((s) => s.id)

    const entryRows = showIds.length
      ? await db
          .select({
            id: entries.id,
            showId: entries.showId,
            startNumber: entries.startNumber,
            finalPlace: entries.finalPlace,
            song: {
              id: songs.id,
              title: songs.title,
              artist: songs.artist,
              country: songs.country,
            },
          })
          .from(entries)
          .leftJoin(songs, eq(entries.songId, songs.id))
          .where(inArray(entries.showId, showIds))
          .orderBy(asc(entries.startNumber))
      : []

    const entryIds = entryRows.map((e) => e.id)
    const ratingRows = entryIds.length
      ? await db
          .select({
            entryId: ratings.entryId,
            raterId: ratings.raterId,
            score: ratings.score,
            note: ratings.note,
          })
          .from(ratings)
          .where(inArray(ratings.entryId, entryIds))
      : []
    const predictionRows = entryIds.length
      ? await db
          .select({
            entryId: predictions.entryId,
            raterId: predictions.raterId,
            place: predictions.place,
          })
          .from(predictions)
          .where(inArray(predictions.entryId, entryIds))
      : []

    return {
      contest,
      shows: SHOW_KINDS.flatMap((kind) => {
        const show = showRows.find((s) => s.kind === kind)
        if (!show) return []
        return [
          {
            id: show.id,
            kind,
            entries: entryRows
              .filter((e) => e.showId === show.id)
              .map((e) => ({
                id: e.id,
                startNumber: e.startNumber,
                song: e.song?.id ? e.song : null,
                finalPlace: e.finalPlace,
                ratings: ratingRows.filter((r) => r.entryId === e.id),
                predictions: predictionRows.filter((p) => p.entryId === e.id),
              })),
          },
        ]
      }),
    }
  })

/* ------------------------------ Start numbers ------------------------------ */

export const setEntrySong = createServerFn({ method: 'POST' })
  .validator(z.object({ entryId: id, songId: id.nullable() }))
  .handler(async ({ data }) => {
    const [entry] = await db
      .select({ songId: entries.songId })
      .from(entries)
      .where(eq(entries.id, data.entryId))
    if (!entry) throw new Error('Start number not found')
    if (entry.songId === data.songId) return { ok: true }

    // A different song is a different performance, so earlier scores,
    // predictions and the result go.
    await db.delete(ratings).where(eq(ratings.entryId, data.entryId))
    await db.delete(predictions).where(eq(predictions.entryId, data.entryId))
    await db
      .update(entries)
      .set({ songId: data.songId, finalPlace: null })
      .where(eq(entries.id, data.entryId))
    return { ok: true }
  })

export const addEntry = createServerFn({ method: 'POST' })
  .validator(z.object({ showId: id }))
  .handler(async ({ data }) => {
    const [{ last }] = await db
      .select({ last: max(entries.startNumber) })
      .from(entries)
      .where(eq(entries.showId, data.showId))
    await db
      .insert(entries)
      .values({ showId: data.showId, startNumber: (last ?? 0) + 1 })
    return { ok: true }
  })

export const removeLastEntry = createServerFn({ method: 'POST' })
  .validator(z.object({ showId: id }))
  .handler(async ({ data }) => {
    const [{ last }] = await db
      .select({ last: max(entries.startNumber) })
      .from(entries)
      .where(eq(entries.showId, data.showId))
    if (last == null) return { ok: true }
    await db
      .delete(entries)
      .where(
        and(eq(entries.showId, data.showId), eq(entries.startNumber, last)),
      )
    return { ok: true }
  })

/* --------------------------------- Ratings --------------------------------- */

export const setRating = createServerFn({ method: 'POST' })
  .validator(
    z.object({
      entryId: id,
      raterId: id,
      score: z.number().int().min(1).max(MAX_POINTS).nullable(),
      note: z.string().trim().max(500).default(''),
    }),
  )
  .handler(async ({ data }) => {
    const where = and(
      eq(ratings.entryId, data.entryId),
      eq(ratings.raterId, data.raterId),
    )
    if (data.score == null) {
      await db.delete(ratings).where(where)
      return { ok: true }
    }
    await db
      .insert(ratings)
      .values({
        entryId: data.entryId,
        raterId: data.raterId,
        score: data.score,
        note: data.note,
      })
      .onConflictDoUpdate({
        target: [ratings.entryId, ratings.raterId],
        set: { score: data.score, note: data.note, updatedAt: new Date() },
      })
    return { ok: true }
  })

/* ------------------------------ Points battle ------------------------------ */

const place = z.number().int().min(1).max(99).nullable()

export const setPrediction = createServerFn({ method: 'POST' })
  .validator(z.object({ entryId: id, raterId: id, place }))
  .handler(async ({ data }) => {
    const where = and(
      eq(predictions.entryId, data.entryId),
      eq(predictions.raterId, data.raterId),
    )
    if (data.place == null) {
      await db.delete(predictions).where(where)
      return { ok: true }
    }
    await db
      .insert(predictions)
      .values({
        entryId: data.entryId,
        raterId: data.raterId,
        place: data.place,
      })
      .onConflictDoUpdate({
        target: [predictions.entryId, predictions.raterId],
        set: { place: data.place, updatedAt: new Date() },
      })
    return { ok: true }
  })

// Actual place of an entry within its show.
export const setFinalPlace = createServerFn({ method: 'POST' })
  .validator(z.object({ entryId: id, place }))
  .handler(async ({ data }) => {
    await db
      .update(entries)
      .set({ finalPlace: data.place })
      .where(eq(entries.id, data.entryId))
    return { ok: true }
  })
