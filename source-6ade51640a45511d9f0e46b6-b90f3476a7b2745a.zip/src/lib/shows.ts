export const SHOW_KINDS = ['semi1', 'semi2', 'final'] as const
export type ShowKind = (typeof SHOW_KINDS)[number]

export const SHOW_LABELS: Record<ShowKind, string> = {
  semi1: 'Semi-final 1',
  semi2: 'Semi-final 2',
  final: 'Grand Final',
}

export const SHOW_SHORT: Record<ShowKind, string> = {
  semi1: 'SF1',
  semi2: 'SF2',
  final: 'Final',
}

// Typical running-order sizes, prefilled in the "new year" form.
export const DEFAULT_COUNTS: Record<ShowKind, number> = {
  semi1: 15,
  semi2: 16,
  final: 26,
}

// The top places of each semi-final go through to the Grand Final.
export const QUALIFIERS = 10

// Ratings are 1–10 points.
export const MAX_POINTS = 10
export const POINTS = Array.from({ length: MAX_POINTS }, (_, i) => i + 1)
