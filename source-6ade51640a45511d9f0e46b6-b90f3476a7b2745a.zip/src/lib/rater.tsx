import { createContext, useContext, useEffect, useState } from 'react'

export type Rater = { id: number; name: string }

type RaterContextValue = {
  raters: Rater[]
  current: Rater | null
  setCurrentId: (id: number | null) => void
}

const RaterContext = createContext<RaterContextValue>({
  raters: [],
  current: null,
  setCurrentId: () => {},
})

const STORAGE_KEY = 'esc-rater-id'

export function RaterProvider({
  raters,
  children,
}: {
  raters: Rater[]
  children: React.ReactNode
}) {
  const [currentId, setId] = useState<number | null>(null)

  useEffect(() => {
    const stored = Number(localStorage.getItem(STORAGE_KEY))
    if (stored) setId(stored)
  }, [])

  const setCurrentId = (id: number | null) => {
    setId(id)
    if (id) localStorage.setItem(STORAGE_KEY, String(id))
    else localStorage.removeItem(STORAGE_KEY)
  }

  const current = raters.find((r) => r.id === currentId) ?? null

  return (
    <RaterContext.Provider value={{ raters, current, setCurrentId }}>
      {children}
    </RaterContext.Provider>
  )
}

export const useRaters = () => useContext(RaterContext)

// Stable per-rater accent colours (indexes into the chart palette).
export function raterColor(raters: Rater[], id: number) {
  const index = raters.findIndex((r) => r.id === id)
  return `var(--chart-${(Math.max(index, 0) % 5) + 1})`
}

export function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]!.toUpperCase())
    .join('')
}
