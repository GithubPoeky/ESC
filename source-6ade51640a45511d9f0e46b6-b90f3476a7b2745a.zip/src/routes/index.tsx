import { useState } from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import { CalendarPlus, Music, Users } from 'lucide-react'

import { FriendsDialog, RaterAvatar } from '@/components/site-header'
import { NewYearDialog } from '@/components/new-year-dialog'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { listContests } from '@/lib/eurovision.functions'
import { useRaters } from '@/lib/rater'

export const Route = createFileRoute('/')({
  loader: () => listContests(),
  component: Home,
})

function Home() {
  const contests = Route.useLoaderData()
  const { raters } = useRaters()
  const [newYearOpen, setNewYearOpen] = useState(false)
  const [friendsOpen, setFriendsOpen] = useState(false)

  const thisYear = new Date().getFullYear()
  const suggestedYear = contests.some((c) => c.year === thisYear)
    ? Math.max(...contests.map((c) => c.year)) + 1
    : thisYear

  return (
    <>
      <section className="py-14 sm:py-20">
        <h1 className="font-display text-5xl leading-[1.05] font-black tracking-tight sm:text-7xl">
          Eurovision <span className="text-stage">Song Contest</span>
        </h1>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Button size="lg" onClick={() => setNewYearOpen(true)}>
            <CalendarPlus /> New Eurovision year
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/songs">
              <Music /> Song library
            </Link>
          </Button>
          <button
            type="button"
            onClick={() => setFriendsOpen(true)}
            className="ml-1 flex items-center gap-2 rounded-full py-1 pr-3 pl-1 text-sm text-muted-foreground transition-colors hover:text-foreground motion-reduce:transition-none"
          >
            {raters.length ? (
              <span className="flex -space-x-2">
                {raters.map((r) => (
                  <RaterAvatar
                    key={r.id}
                    rater={r}
                    className="size-8 text-xs ring-2 ring-background"
                  />
                ))}
              </span>
            ) : (
              <Users className="size-4" />
            )}
            {raters.length
              ? `${raters.length} on the jury`
              : 'Add your jury first'}
          </button>
        </div>
      </section>

      <section aria-labelledby="years-heading">
        <h2
          id="years-heading"
          className="mb-5 font-display text-xl font-bold tracking-tight"
        >
          Contest years
        </h2>

        {contests.length === 0 ? (
          <div className="rounded-2xl border border-dashed p-10 text-center">
            <p className="font-display text-lg font-bold">No years yet</p>
            <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
              Create your first Eurovision year — the two semi-finals and the
              final are set up for you.
            </p>
            <Button className="mt-5" onClick={() => setNewYearOpen(true)}>
              <CalendarPlus /> New Eurovision year
            </Button>
          </div>
        ) : (
          <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {contests.map((c) => (
              <li key={c.id}>
                <Link
                  to="/years/$year"
                  params={{ year: String(c.year) }}
                  className="group relative block overflow-hidden rounded-2xl border bg-card p-6 transition-colors hover:border-primary/60 motion-reduce:transition-none"
                >
                  <span
                    aria-hidden
                    className="absolute -top-16 -right-16 size-40 rounded-full bg-primary/20 blur-3xl transition-opacity group-hover:opacity-100 sm:opacity-60"
                  />
                  <p className="font-display text-5xl font-black tracking-tight">
                    {c.year}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {c.hostCity || 'Host city not set'}
                  </p>
                  <div className="mt-6 space-y-2">
                    <div className="flex justify-between text-xs text-muted-foreground">
                      <span>
                        {c.filled} / {c.slots} start numbers filled
                      </span>
                      <span>{c.ratings} ratings</span>
                    </div>
                    <Progress
                      value={c.slots ? (c.filled / c.slots) * 100 : 0}
                      aria-label={`${c.year} running order progress`}
                    />
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>

      <NewYearDialog
        key={suggestedYear}
        open={newYearOpen}
        onOpenChange={setNewYearOpen}
        suggestedYear={suggestedYear}
      />
      <FriendsDialog open={friendsOpen} onOpenChange={setFriendsOpen} />
    </>
  )
}
