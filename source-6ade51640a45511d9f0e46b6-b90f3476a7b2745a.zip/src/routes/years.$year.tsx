import { useMemo, useState } from 'react'
import {
  Link,
  createFileRoute,
  notFound,
  useNavigate,
  useRouter,
} from '@tanstack/react-router'
import {
  ArrowLeft,
  Crown,
  ListOrdered,
  MapPin,
  CircleMinus,
  Ellipsis,
  Pencil,
  Plus,
  CirclePlus,
  Swords,
  Trash2,
  Trophy,
} from 'lucide-react'
import { toast } from 'sonner'

import { PointsBattle } from '@/components/points-battle'
import { PlaceInput } from '@/components/place-input'
import { ScoreChip, pointsStyle } from '@/components/score-chip'
import { RaterAvatar } from '@/components/site-header'
import { SongDialog, type Song } from '@/components/song-dialog'
import { SongPicker } from '@/components/song-picker'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Flag } from '@/components/flag'
import {
  addEntry,
  deleteContest,
  getContest,
  listSongs,
  removeLastEntry,
  setEntrySong,
  setFinalPlace,
  updateContest,
} from '@/lib/eurovision.functions'
import { useRaters, type Rater } from '@/lib/rater'
import { MAX_POINTS, QUALIFIERS, SHOW_LABELS, SHOW_SHORT, type ShowKind } from '@/lib/shows'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/years/$year')({
  loader: async ({ params }) => {
    const year = Number(params.year)
    if (!Number.isInteger(year)) throw notFound()
    const [data, songs] = await Promise.all([
      getContest({ data: { year } }),
      listSongs(),
    ])
    if (!data) throw notFound()
    return { ...data, songs }
  },
  head: ({ params }) => ({
    meta: [{ title: `Eurovision ${params.year} · Eurovision Song Contest Scoreboard` }],
  }),
  component: YearPage,
})

type ContestData = NonNullable<Awaited<ReturnType<typeof getContest>>>
type Show = ContestData['shows'][number]
type Entry = Show['entries'][number]

function YearPage() {
  const { contest, shows, songs } = Route.useLoaderData()
  const router = useRouter()
  const navigate = useNavigate()
  const [tab, setTab] = useState<ShowKind>('semi1')
  const [editingCity, setEditingCity] = useState<string | null>(null)

  const usedInYear = useMemo(
    () =>
      new Set(
        shows.flatMap((s) =>
          s.entries.flatMap((e) => (e.song ? [e.song.id] : [])),
        ),
      ),
    [shows],
  )

  const refresh = () => router.invalidate()

  const saveCity = async (e: React.FormEvent) => {
    e.preventDefault()
    if (editingCity == null) return
    try {
      await updateContest({ data: { id: contest.id, hostCity: editingCity } })
      setEditingCity(null)
      await refresh()
    } catch {
      toast.error('Could not save the host city')
    }
  }

  const removeYear = async () => {
    if (
      !confirm(
        `Delete Eurovision ${contest.year}? All start numbers and ratings for this year are removed. Songs stay in the library.`,
      )
    )
      return
    try {
      await deleteContest({ data: { id: contest.id } })
      toast.success(`${contest.year} deleted`)
      await navigate({ to: '/' })
    } catch {
      toast.error('Could not delete the year')
    }
  }

  return (
    <div className="pt-8">
      <Link
        to="/"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> All years
      </Link>

      <div className="mt-4 flex flex-wrap items-end gap-4">
        <div className="min-w-0 flex-1">
          <h1 className="font-display text-4xl font-black tracking-tight sm:text-5xl">
            Eurovision <span className="text-stage">{contest.year}</span>
          </h1>
          {editingCity != null ? (
            <form onSubmit={saveCity} className="mt-2 flex max-w-sm gap-2">
              <Input
                autoFocus
                aria-label="Host city"
                placeholder="Host city"
                value={editingCity}
                onChange={(e) => setEditingCity(e.target.value)}
              />
              <Button type="submit" size="sm" className="h-9">
                Save
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-9"
                onClick={() => setEditingCity(null)}
              >
                Cancel
              </Button>
            </form>
          ) : (
            <button
              type="button"
              onClick={() => setEditingCity(contest.hostCity)}
              className="group mt-2 inline-flex items-center gap-1.5 text-muted-foreground hover:text-foreground"
            >
              <MapPin className="size-4" />
              {contest.hostCity || 'Add host city'}
              <Pencil className="size-3 opacity-0 group-hover:opacity-100" />
            </button>
          )}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Year options">
              <Ellipsis />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem variant="destructive" onSelect={removeYear}>
              <Trash2 /> Delete {contest.year}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <Tabs
        value={tab}
        onValueChange={(v) => setTab(v as ShowKind)}
        className="mt-8"
      >
        <TabsList className="h-auto w-full justify-start gap-1 overflow-x-auto rounded-xl p-1 sm:w-auto">
          {shows.map((s) => {
            const filled = s.entries.filter((e) => e.song).length
            return (
              <TabsTrigger
                key={s.kind}
                value={s.kind}
                className="rounded-lg px-4 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <span className="sm:hidden">{SHOW_SHORT[s.kind]}</span>
                <span className="hidden sm:inline">{SHOW_LABELS[s.kind]}</span>
                <span className="ml-1.5 text-xs opacity-75">
                  {filled}/{s.entries.length}
                </span>
              </TabsTrigger>
            )
          })}
        </TabsList>
        {shows.map((s) => (
          <TabsContent key={s.kind} value={s.kind} className="mt-6">
            <ShowPanel
              show={s}
              songs={songs}
              usedInYear={usedInYear}
              onChange={refresh}
            />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function stats(entry: Entry) {
  const total = entry.ratings.reduce((sum, r) => sum + r.score, 0)
  const count = entry.ratings.length
  return { total, count, average: count ? total / count : null }
}

function ShowPanel({
  show,
  songs,
  usedInYear,
  onChange,
}: {
  show: Show
  songs: Song[]
  usedInYear: Set<number>
  onChange: () => Promise<void>
}) {
  const { raters, current } = useRaters()
  const [view, setView] = useState<'order' | 'board' | 'battle'>('order')
  const [creatingFor, setCreatingFor] = useState<{
    entryId: number
    query: string
  } | null>(null)
  const [busy, setBusy] = useState(false)

  const assign = async (entryId: number, songId: number | null) => {
    const entry = show.entries.find((e) => e.id === entryId)
    if (
      entry?.song &&
      entry.song.id !== songId &&
      (entry.ratings.length > 0 || entry.predictions.length > 0) &&
      !confirm(
        `Start number ${entry.startNumber} already has ratings or predictions for “${entry.song.title}”. Changing the song clears them. Continue?`,
      )
    )
      return
    try {
      await setEntrySong({ data: { entryId, songId } })
      await onChange()
    } catch {
      toast.error('Could not update the start number')
    }
  }

  const changeSlots = async (fn: () => Promise<unknown>) => {
    setBusy(true)
    try {
      await fn()
      await onChange()
    } catch {
      toast.error('Could not update the running order')
    } finally {
      setBusy(false)
    }
  }

  const myRated = current
    ? show.entries.filter((e) =>
        e.ratings.some((r) => r.raterId === current.id),
      ).length
    : 0
  const withSong = show.entries.filter((e) => e.song)

  return (
    <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          {current
            ? `You've rated ${myRated} of ${withSong.length} songs in this show.`
            : raters.length
              ? 'Pick who you are in the top corner to highlight your scores.'
              : 'Add your jury from the menu in the top corner to start rating.'}
        </p>
        <div className="flex rounded-full border p-0.5" role="group" aria-label="View">
          {(
            [
              ['order', 'Running order', ListOrdered],
              ['board', 'Leaderboard', Trophy],
              ...(show.kind === 'final'
                ? ([['battle', 'Points battle', Swords]] as const)
                : []),
            ] as const
          ).map(([key, label, Icon]) => (
            <button
              key={key}
              type="button"
              aria-pressed={view === key}
              onClick={() => setView(key)}
              className={cn(
                'flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm font-semibold transition-colors motion-reduce:transition-none',
                view === key
                  ? 'bg-secondary text-foreground'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              <Icon className="size-4" />{' '}
              <span className={cn(show.kind === 'final' && 'max-sm:sr-only')}>
                {label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {view === 'order' ? (
        <>
          {show.entries.length === 0 ? (
            <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-muted-foreground">
              No start numbers in this show yet.
            </div>
          ) : (
            <ol className="space-y-2">
              {show.entries.map((entry) => (
                <EntryRow
                  key={entry.id}
                  entry={entry}
                  show={show}
                  raters={raters}
                  songs={songs}
                  usedInYear={usedInYear}
                  onAssign={(songId) => assign(entry.id, songId)}
                  onCreate={(query) =>
                    setCreatingFor({ entryId: entry.id, query })
                  }
                  onChange={onChange}
                />
              ))}
            </ol>
          )}
          <div className="mt-4 flex flex-wrap gap-2">
            <Button
              variant="outline"
              disabled={busy}
              onClick={() => changeSlots(() => addEntry({ data: { showId: show.id } }))}
            >
              <CirclePlus /> Add start number
            </Button>
            {show.entries.length > 0 && (
              <Button
                variant="ghost"
                disabled={busy}
                onClick={() => {
                  const last = show.entries[show.entries.length - 1]
                  if (
                    last?.song &&
                    !confirm(
                      `Remove start number ${last.startNumber} (${last.song.title})? Its ratings are deleted too.`,
                    )
                  )
                    return
                  void changeSlots(() =>
                    removeLastEntry({ data: { showId: show.id } }),
                  )
                }}
              >
                <CircleMinus /> Remove last
              </Button>
            )}
          </div>
        </>
      ) : view === 'board' ? (
        <Leaderboard show={show} raters={raters} />
      ) : (
        <PointsBattle entries={show.entries} onChange={onChange} />
      )}

      <SongDialog
        open={creatingFor != null}
        onOpenChange={(open) => !open && setCreatingFor(null)}
        initial={{ title: creatingFor?.query ?? '' }}
        onSaved={async (song) => {
          if (creatingFor) await assign(creatingFor.entryId, song.id)
        }}
      />
    </>
  )
}

function EntryRow({
  entry,
  show,
  raters,
  songs,
  usedInYear,
  onAssign,
  onCreate,
  onChange,
}: {
  entry: Entry
  show: Show
  raters: Rater[]
  songs: Song[]
  usedInYear: Set<number>
  onAssign: (songId: number | null) => void
  onCreate: (query: string) => void
  onChange: () => Promise<void>
}) {
  const { average } = stats(entry)
  const places = show.entries.filter((e) => e.song).length
  const place = entry.finalPlace
  const qualified = show.kind !== 'final' && place != null && place <= QUALIFIERS

  const savePlace = async (next: number | null) => {
    try {
      await setFinalPlace({ data: { entryId: entry.id, place: next } })
      await onChange()
    } catch {
      toast.error('Could not save the place')
    }
  }

  return (
    <li className="flex flex-col gap-3 rounded-xl border bg-card p-3 sm:flex-row sm:items-center">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-lg bg-secondary font-display text-lg font-black">
          {String(entry.startNumber).padStart(2, '0')}
        </span>
        <SongPicker
          songs={songs}
          usedInYear={usedInYear}
          selectedId={entry.song?.id ?? null}
          onSelect={onAssign}
          onCreate={onCreate}
        >
          {entry.song ? (
            <button
              type="button"
              className="flex min-w-0 flex-1 items-center gap-3 rounded-lg px-2 py-1 text-left hover:bg-accent/60"
              aria-label={`Start number ${entry.startNumber}: ${entry.song.title} by ${entry.song.artist}. Change song`}
            >
              <Flag country={entry.song.country} className="h-7" />
              <span className="min-w-0">
                <span className="block truncate font-bold">
                  {entry.song.title}
                </span>
                <span className="block truncate text-sm text-muted-foreground">
                  {entry.song.artist} · {entry.song.country}
                </span>
              </span>
            </button>
          ) : (
            <button
              type="button"
              className="flex flex-1 items-center gap-2 rounded-lg border border-dashed px-3 py-2.5 text-sm text-muted-foreground hover:border-primary hover:text-foreground"
            >
              <Plus className="size-4" /> Pick a song for start number{' '}
              {entry.startNumber}
            </button>
          )}
        </SongPicker>
      </div>

      {entry.song && (
        <div className="flex items-center gap-1.5 sm:justify-end">
          {raters.map((r) => {
            const rating = entry.ratings.find((x) => x.raterId === r.id)
            return (
              <ScoreChip
                key={r.id}
                entryId={entry.id}
                rater={r}
                score={rating?.score ?? null}
                note={rating?.note ?? ''}
                onSaved={onChange}
              />
            )
          })}
          <span
            className="ml-2 w-12 text-right"
            aria-label={average == null ? 'No average yet' : `Average ${average.toFixed(1)}`}
          >
            <span className="block font-display text-base font-bold">
              {average == null ? '–' : average.toFixed(1)}
            </span>
            <span className="block text-[0.6rem] tracking-wider text-muted-foreground uppercase">
              avg
            </span>
          </span>
          <span className="ml-2 flex flex-col items-center border-l pl-3">
            <PlaceInput
              value={place}
              max={places}
              label={`Actual place for ${entry.song.country}`}
              warning={
                place != null &&
                show.entries.some((o) => o.id !== entry.id && o.finalPlace === place)
                  ? `Place ${place} is used twice`
                  : undefined
              }
              className={cn('h-8 w-12 text-sm', place === 1 && 'border-gold text-gold')}
              onSave={savePlace}
            />
            <span
              className={cn(
                'mt-0.5 text-[0.6rem] font-bold tracking-wider uppercase',
                qualified ? 'text-score-high' : 'text-muted-foreground',
              )}
            >
              {qualified ? 'Qualified' : 'Place'}
            </span>
          </span>
        </div>
      )}
    </li>
  )
}

function Leaderboard({ show, raters }: { show: Show; raters: Rater[] }) {
  const ranked = show.entries
    .filter((e) => e.song)
    .map((e) => ({ entry: e, ...stats(e) }))
    .sort(
      (a, b) =>
        b.total - a.total ||
        (b.average ?? 0) - (a.average ?? 0) ||
        a.entry.startNumber - b.entry.startNumber,
    )

  const douze = raters.flatMap((r) => {
    const best = show.entries
      .filter((e) => e.song)
      .map((e) => ({ e, s: e.ratings.find((x) => x.raterId === r.id)?.score }))
      .filter((x) => x.s != null)
      .sort((a, b) => b.s! - a.s!)[0]
    return best ? [{ rater: r, song: best.e.song!, score: best.s! }] : []
  })

  if (ranked.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-muted-foreground">
        Pick songs for the start numbers to see the leaderboard.
      </div>
    )
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_18rem]">
      <ol className="space-y-2">
        {ranked.map(({ entry, total, count, average }, i) => (
          <li
            key={entry.id}
            className={cn(
              'flex items-center gap-3 rounded-xl border bg-card p-3',
              i === 0 && total > 0 && 'border-gold/60 shadow-[0_0_32px_-12px_var(--gold)]',
            )}
          >
            <span
              className={cn(
                'flex size-9 shrink-0 items-center justify-center rounded-full font-display text-sm font-black',
                i === 0 && total > 0 ? 'bg-gold text-background' : 'bg-secondary',
              )}
            >
              {i === 0 && total > 0 ? <Crown className="size-4" /> : i + 1}
            </span>
            <Flag country={entry.song!.country} className="h-6" />
            <span className="min-w-0 flex-1">
              <span className="block truncate font-bold">
                {entry.song!.title}
              </span>
              <span className="block truncate text-sm text-muted-foreground">
                {entry.song!.artist} · {entry.song!.country} · #
                {entry.startNumber}
              </span>
            </span>
            <span className="hidden gap-1 md:flex">
              {raters.map((r) => {
                const s = entry.ratings.find((x) => x.raterId === r.id)?.score
                return (
                  <span
                    key={r.id}
                    title={r.name}
                    className={cn(
                      'flex size-7 items-center justify-center rounded-md text-xs font-bold',
                      s == null ? 'bg-muted/50 text-muted-foreground' : 'text-background',
                    )}
                    style={s == null ? undefined : pointsStyle(s)}
                  >
                    {s ?? '–'}
                  </span>
                )
              })}
            </span>
            <span className="w-16 text-right">
              <span className="block font-display text-xl font-black">
                {total}
              </span>
              <span className="block text-[0.65rem] text-muted-foreground">
                {count ? `avg ${average!.toFixed(1)}` : 'no votes'}
              </span>
              {entry.finalPlace != null && (
                <span className="block text-[0.65rem] font-semibold text-cyan">
                  finished #{entry.finalPlace}
                </span>
              )}
            </span>
          </li>
        ))}
      </ol>

      <aside className="h-fit rounded-2xl border bg-card p-5">
        <h3 className="flex items-center gap-2 text-sm font-bold">
          <span className="rounded-md bg-gold px-1.5 py-0.5 font-display text-xs text-background">
            {MAX_POINTS}
          </span>
          Top picks
        </h3>
        {douze.length === 0 ? (
          <p className="mt-3 text-sm text-muted-foreground">
            No votes yet in {SHOW_LABELS[show.kind]}.
          </p>
        ) : (
          <ul className="mt-4 space-y-3">
            {douze.map(({ rater, song, score }) => (
              <li key={rater.id} className="flex items-center gap-3">
                <RaterAvatar rater={rater} />
                <span className="min-w-0 flex-1">
                  <span className="block text-xs text-muted-foreground">
                    {rater.name} gives {score} to
                  </span>
                  <span className="flex items-center gap-1.5 truncate text-sm font-semibold">
                    <Flag country={song.country} className="h-3.5" />
                    <span className="truncate">{song.title}</span>
                  </span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </aside>
    </div>
  )
}
