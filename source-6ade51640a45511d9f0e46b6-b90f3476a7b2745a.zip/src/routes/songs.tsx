import { useMemo, useState } from 'react'
import { createFileRoute, useRouter } from '@tanstack/react-router'
import { Music, Pencil, Plus, Search, Trash2 } from 'lucide-react'
import { toast } from 'sonner'

import { SongDialog, type Song } from '@/components/song-dialog'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Flag } from '@/components/flag'
import { deleteSong, listSongs } from '@/lib/eurovision.functions'

export const Route = createFileRoute('/songs')({
  loader: () => listSongs(),
  head: () => ({ meta: [{ title: 'Song library · Eurovision Song Contest Scoreboard' }] }),
  component: SongsPage,
})

function SongsPage() {
  const songs = Route.useLoaderData()
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [dialog, setDialog] = useState<{ song: Song | null } | null>(null)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return songs
    return songs.filter((s) =>
      [s.title, s.artist, s.country, ...s.years.map(String)].some((v) =>
        v.toLowerCase().includes(q),
      ),
    )
  }, [songs, query])

  const remove = async (song: Song & { years: number[] }) => {
    const usage = song.years.length
      ? ` It is used in ${song.years.join(', ')} — those start numbers become empty and their ratings are removed.`
      : ''
    if (!confirm(`Delete “${song.title}” from the library?${usage}`)) return
    try {
      await deleteSong({ data: { id: song.id } })
      await router.invalidate()
      toast.success('Song deleted')
    } catch {
      toast.error('Could not delete the song')
    }
  }

  return (
    <div className="pt-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl font-black tracking-tight">
            Song library
          </h1>
          <p className="mt-2 max-w-reading text-muted-foreground">
            Every song you add here can be picked for a start number in any
            semi-final or final.
          </p>
        </div>
        <Button onClick={() => setDialog({ song: null })}>
          <Plus /> New song
        </Button>
      </div>

      <div className="relative mt-8 max-w-md">
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          aria-label="Search songs"
          placeholder="Search title, artist, country or year"
          className="pl-9"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {songs.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed p-10 text-center">
          <Music className="mx-auto size-8 text-muted-foreground" />
          <p className="mt-3 font-display text-lg font-bold">
            The library is empty
          </p>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            Add songs here, or create them straight from a start number.
          </p>
        </div>
      ) : filtered.length === 0 ? (
        <p className="mt-6 text-sm text-muted-foreground">
          No songs match “{query}”.
        </p>
      ) : (
        <ul className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((song) => (
            <li
              key={song.id}
              className="group flex items-center gap-3 rounded-xl border bg-card p-4"
            >
              <Flag country={song.country} className="h-8" />
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold">{song.title}</p>
                <p className="truncate text-sm text-muted-foreground">
                  {song.artist} · {song.country}
                </p>
                {song.years.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {song.years.map((y) => (
                      <Badge key={y} variant="secondary" className="text-[0.65rem]">
                        {y}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex flex-col gap-1">
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Edit ${song.title}`}
                  onClick={() => setDialog({ song })}
                >
                  <Pencil />
                </Button>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Delete ${song.title}`}
                  onClick={() => remove(song)}
                >
                  <Trash2 />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <SongDialog
        open={dialog != null}
        onOpenChange={(open) => !open && setDialog(null)}
        song={dialog?.song}
        onSaved={() => router.invalidate()}
      />
    </div>
  )
}
