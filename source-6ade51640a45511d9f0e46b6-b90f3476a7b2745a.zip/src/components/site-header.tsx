import { useState } from 'react'
import { Link, useRouter } from '@tanstack/react-router'
import { Check, ChevronDown, MicVocal, Pencil, Trash2, Users } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import {
  createRater,
  deleteRater,
  renameRater,
} from '@/lib/eurovision.functions'
import { initials, raterColor, useRaters, type Rater } from '@/lib/rater'

export function RaterAvatar({
  rater,
  className = 'size-7 text-[0.65rem]',
}: {
  rater: Rater
  className?: string
}) {
  const { raters } = useRaters()
  return (
    <span
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-bold text-background ${className}`}
      style={{ background: raterColor(raters, rater.id) }}
      aria-hidden
    >
      {initials(rater.name)}
    </span>
  )
}

export function SiteHeader() {
  const { raters, current, setCurrentId } = useRaters()
  const [manageOpen, setManageOpen] = useState(false)

  const navClass =
    'rounded-full px-3 py-1.5 text-sm font-semibold text-muted-foreground transition-colors hover:text-foreground motion-reduce:transition-none'
  const activeClass = 'bg-secondary text-foreground'

  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-content items-center gap-3 px-4 sm:px-6">
        <Link to="/" className="mr-2 flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-[0_0_24px_var(--primary)]">
            <MicVocal className="size-4" />
          </span>
          <span className="hidden font-display text-sm font-bold tracking-tight sm:block">
            Eurovision Song Contest Scoreboard
          </span>
        </Link>

        <nav className="flex items-center gap-1">
          <Link
            to="/"
            className={navClass}
            activeProps={{ className: activeClass }}
            activeOptions={{ exact: true }}
          >
            Years
          </Link>
          <Link
            to="/songs"
            className={navClass}
            activeProps={{ className: activeClass }}
          >
            Songs
          </Link>
        </nav>

        <div className="ml-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="rounded-full pl-1.5">
                {current ? (
                  <RaterAvatar rater={current} />
                ) : (
                  <span className="flex size-7 items-center justify-center rounded-full bg-muted">
                    <Users className="size-3.5" />
                  </span>
                )}
                <span className="max-w-28 truncate">
                  {current ? current.name : 'Who are you?'}
                </span>
                <ChevronDown className="text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Rating as…</DropdownMenuLabel>
              {raters.length === 0 && (
                <p className="px-2 py-1.5 text-sm text-muted-foreground">
                  No friends added yet.
                </p>
              )}
              {raters.map((r) => (
                <DropdownMenuItem key={r.id} onSelect={() => setCurrentId(r.id)}>
                  <RaterAvatar rater={r} className="size-6 text-[0.6rem]" />
                  <span className="flex-1 truncate">{r.name}</span>
                  {current?.id === r.id && <Check />}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => setManageOpen(true)}>
                <Users /> Manage friends
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      <FriendsDialog open={manageOpen} onOpenChange={setManageOpen} />
    </header>
  )
}

export function FriendsDialog({
  open,
  onOpenChange,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
}) {
  const router = useRouter()
  const { raters, current, setCurrentId } = useRaters()
  const [newName, setNewName] = useState('')
  const [editing, setEditing] = useState<{ id: number; name: string } | null>(
    null,
  )
  const [busy, setBusy] = useState(false)

  const run = async (fn: () => Promise<unknown>, message: string) => {
    setBusy(true)
    try {
      await fn()
      await router.invalidate()
    } catch {
      toast.error(message)
    } finally {
      setBusy(false)
    }
  }

  const add = (e: React.FormEvent) => {
    e.preventDefault()
    const name = newName.trim()
    if (!name) return
    void run(async () => {
      const rater = await createRater({ data: { name } })
      setNewName('')
      if (!current) setCurrentId(rater.id)
    }, 'Could not add friend')
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>The jury</DialogTitle>
          <DialogDescription>
            Everyone who rates songs. Pick yourself from the menu in the top
            corner to start voting.
          </DialogDescription>
        </DialogHeader>

        <ul className="space-y-2">
          {raters.map((r) => (
            <li
              key={r.id}
              className="flex items-center gap-2 rounded-lg border bg-muted/40 p-2"
            >
              <RaterAvatar rater={r} />
              {editing?.id === r.id ? (
                <form
                  className="flex flex-1 gap-2"
                  onSubmit={(e) => {
                    e.preventDefault()
                    const name = editing.name.trim()
                    if (!name) return
                    void run(async () => {
                      await renameRater({ data: { id: r.id, name } })
                      setEditing(null)
                    }, 'Could not rename')
                  }}
                >
                  <Input
                    autoFocus
                    aria-label="Name"
                    value={editing.name}
                    maxLength={40}
                    onChange={(e) =>
                      setEditing({ id: r.id, name: e.target.value })
                    }
                  />
                  <Button type="submit" size="sm" disabled={busy}>
                    Save
                  </Button>
                </form>
              ) : (
                <>
                  <span className="flex-1 truncate font-semibold">{r.name}</span>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Rename ${r.name}`}
                    onClick={() => setEditing({ id: r.id, name: r.name })}
                  >
                    <Pencil />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Remove ${r.name}`}
                    disabled={busy}
                    onClick={() => {
                      if (
                        !confirm(
                          `Remove ${r.name}? All of their ratings are deleted too.`,
                        )
                      )
                        return
                      void run(async () => {
                        await deleteRater({ data: { id: r.id } })
                        if (current?.id === r.id) setCurrentId(null)
                      }, 'Could not remove')
                    }}
                  >
                    <Trash2 />
                  </Button>
                </>
              )}
            </li>
          ))}
        </ul>

        <form onSubmit={add} className="flex gap-2">
          <Input
            placeholder="Friend's name"
            aria-label="Friend's name"
            value={newName}
            maxLength={40}
            onChange={(e) => setNewName(e.target.value)}
          />
          <Button type="submit" disabled={busy || !newName.trim()}>
            Add
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  )
}
