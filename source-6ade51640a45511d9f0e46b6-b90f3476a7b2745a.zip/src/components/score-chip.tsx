import { useEffect, useState } from 'react'
import { MessageSquare } from 'lucide-react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { Textarea } from '@/components/ui/textarea'
import { setRating } from '@/lib/eurovision.functions'
import { initials, raterColor, useRaters, type Rater } from '@/lib/rater'
import { MAX_POINTS, POINTS } from '@/lib/shows'
import { cn } from '@/lib/utils'

/** Background along the red → white → green points scale. */
export function pointsStyle(score: number): React.CSSProperties {
  const t = (score - 1) / (MAX_POINTS - 1)
  const background =
    t <= 0.5
      ? `color-mix(in oklch, var(--score-low) ${Math.round((1 - t * 2) * 100)}%, var(--score-mid))`
      : `color-mix(in oklch, var(--score-high) ${Math.round((t * 2 - 1) * 100)}%, var(--score-mid))`
  return { background }
}

/** One juror's score for one entry; click to set or change it. */
export function ScoreChip({
  entryId,
  rater,
  score,
  note,
  onSaved,
}: {
  entryId: number
  rater: Rater
  score: number | null
  note: string
  onSaved: () => Promise<void>
}) {
  const { raters, current } = useRaters()
  const [open, setOpen] = useState(false)
  const [pending, setPending] = useState<number | null | undefined>(undefined)
  const [draftNote, setDraftNote] = useState(note)

  useEffect(() => {
    if (open) setDraftNote(note)
  }, [open, note])

  const shown = pending !== undefined ? pending : score
  const isMe = current?.id === rater.id

  const save = async (nextScore: number | null, nextNote = note) => {
    setPending(nextScore)
    try {
      await setRating({
        data: { entryId, raterId: rater.id, score: nextScore, note: nextNote },
      })
      await onSaved()
    } catch {
      toast.error('Could not save the rating')
    } finally {
      setPending(undefined)
    }
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          aria-label={`${rater.name}: ${shown ?? 'no'} points. Change rating`}
          className={cn(
            'relative flex h-10 min-w-10 flex-col items-center justify-center rounded-lg border px-1.5 transition-colors hover:border-ring motion-reduce:transition-none',
            isMe ? 'border-ring/70' : 'border-transparent',
            shown == null ? 'bg-muted/50 text-muted-foreground' : 'text-background',
            pending !== undefined && 'animate-pulse',
          )}
          style={shown == null ? undefined : pointsStyle(shown)}
        >
          <span className="font-display text-sm leading-none font-bold">
            {shown ?? '–'}
          </span>
          <span
            className="mt-0.5 text-[0.55rem] leading-none font-bold opacity-80"
            style={shown == null ? { color: raterColor(raters, rater.id) } : undefined}
          >
            {initials(rater.name)}
          </span>
          {note && (
            <MessageSquare
              aria-hidden
              className="absolute -top-1 -right-1 size-3 fill-cyan text-cyan"
            />
          )}
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72" align="end">
        <p className="mb-3 text-sm font-semibold">
          {isMe ? 'Your points' : `${rater.name}'s points`}
        </p>
        <div className="grid grid-cols-5 gap-1.5">
          {POINTS.map((p) => (
            <Button
              key={p}
              size="sm"
              variant="outline"
              aria-pressed={shown === p}
              style={pointsStyle(p)}
              className={cn(
                'border-transparent font-display font-bold text-background hover:text-background hover:brightness-110',
                shown === p && 'ring-2 ring-ring ring-offset-2 ring-offset-popover',
              )}
              onClick={() => {
                setOpen(false)
                void save(p, draftNote)
              }}
            >
              {p}
            </Button>
          ))}
        </div>
        <Textarea
          aria-label="Note"
          placeholder="Notes: staging, vocals, outfit…"
          className="mt-3 min-h-16 text-sm"
          maxLength={500}
          value={draftNote}
          onChange={(e) => setDraftNote(e.target.value)}
        />
        <div className="mt-2 flex justify-between gap-2">
          <Button
            size="sm"
            variant="ghost"
            disabled={shown == null}
            onClick={() => {
              setOpen(false)
              void save(null)
            }}
          >
            Clear
          </Button>
          <Button
            size="sm"
            variant="secondary"
            disabled={shown == null || draftNote === note}
            onClick={() => {
              setOpen(false)
              void save(shown, draftNote)
            }}
          >
            Save note
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}
