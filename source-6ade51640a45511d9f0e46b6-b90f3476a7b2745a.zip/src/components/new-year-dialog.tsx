import { useState } from 'react'
import { useNavigate } from '@tanstack/react-router'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { createContest } from '@/lib/eurovision.functions'
import { DEFAULT_COUNTS, SHOW_KINDS, SHOW_LABELS, type ShowKind } from '@/lib/shows'

export function NewYearDialog({
  open,
  onOpenChange,
  suggestedYear,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  suggestedYear: number
}) {
  const navigate = useNavigate()
  const [year, setYear] = useState(String(suggestedYear))
  const [hostCity, setHostCity] = useState('')
  const [counts, setCounts] = useState<Record<ShowKind, string>>({
    semi1: String(DEFAULT_COUNTS.semi1),
    semi2: String(DEFAULT_COUNTS.semi2),
    final: String(DEFAULT_COUNTS.final),
  })
  const [saving, setSaving] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)
    try {
      const created = await createContest({
        data: {
          year: Number(year),
          hostCity,
          counts: {
            semi1: Number(counts.semi1) || 0,
            semi2: Number(counts.semi2) || 0,
            final: Number(counts.final) || 0,
          },
        },
      })
      onOpenChange(false)
      toast.success(`Eurovision ${created.year} is ready`)
      await navigate({
        to: '/years/$year',
        params: { year: String(created.year) },
      })
    } catch (error) {
      toast.error(
        error instanceof Error && error.message.includes('already exists')
          ? `${year} already exists`
          : 'Could not create the year',
      )
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New Eurovision year</DialogTitle>
          <DialogDescription>
            Creates both semi-finals and the Grand Final with empty start
            numbers, ready for you to fill with songs.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-5">
          <div className="grid grid-cols-[7rem_1fr] gap-3">
            <div className="grid gap-2">
              <Label htmlFor="ny-year">Year</Label>
              <Input
                id="ny-year"
                type="number"
                min={1956}
                max={2100}
                required
                value={year}
                onChange={(e) => setYear(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="ny-city">Host city (optional)</Label>
              <Input
                id="ny-city"
                placeholder="Vienna"
                value={hostCity}
                onChange={(e) => setHostCity(e.target.value)}
              />
            </div>
          </div>
          <fieldset className="grid gap-3">
            <legend className="mb-2 text-sm font-medium">
              Start numbers per show
            </legend>
            <div className="grid grid-cols-3 gap-3">
              {SHOW_KINDS.map((kind) => (
                <div key={kind} className="grid gap-2">
                  <Label
                    htmlFor={`ny-${kind}`}
                    className="text-xs text-muted-foreground"
                  >
                    {SHOW_LABELS[kind]}
                  </Label>
                  <Input
                    id={`ny-${kind}`}
                    type="number"
                    min={0}
                    max={60}
                    value={counts[kind]}
                    onChange={(e) =>
                      setCounts((c) => ({ ...c, [kind]: e.target.value }))
                    }
                  />
                </div>
              ))}
            </div>
            <p className="text-xs text-muted-foreground">
              You can add or remove start numbers later.
            </p>
          </fieldset>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !year}>
              {saving ? 'Creating…' : 'Create year'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
