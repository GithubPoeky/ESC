import { useState } from 'react'
import { toast } from 'sonner'

import { cn } from '@/lib/utils'

/** Small place field that saves on blur or Enter; empty clears it. */
export function PlaceInput({
  value,
  max,
  label,
  warning,
  className,
  onSave,
}: {
  value: number | null
  max: number
  label: string
  warning?: string
  className?: string
  onSave: (place: number | null) => Promise<void>
}) {
  const [draft, setDraft] = useState<string | null>(null)
  const shown = draft ?? (value == null ? '' : String(value))

  const commit = async () => {
    if (draft == null) return
    const trimmed = draft.trim()
    const next = trimmed === '' ? null : Number(trimmed)
    if (next != null && (!Number.isInteger(next) || next < 1 || next > max)) {
      toast.error(`Enter a place from 1 to ${max}`)
      setDraft(null)
      return
    }
    if (next !== value) await onSave(next)
    setDraft(null)
  }

  return (
    <input
      type="number"
      inputMode="numeric"
      min={1}
      max={max}
      aria-label={label}
      title={warning}
      aria-invalid={warning ? true : undefined}
      value={shown}
      placeholder="–"
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => void commit()}
      onKeyDown={(e) => {
        if (e.key === 'Enter') e.currentTarget.blur()
        if (e.key === 'Escape') {
          setDraft(null)
          e.currentTarget.blur()
        }
      }}
      className={cn(
        'h-9 w-14 rounded-md border border-input bg-background text-center font-display font-bold [appearance:textfield] focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/50 focus-visible:outline-none aria-invalid:border-destructive aria-invalid:text-destructive [&::-webkit-inner-spin-button]:appearance-none',
        className,
      )}
    />
  )
}
