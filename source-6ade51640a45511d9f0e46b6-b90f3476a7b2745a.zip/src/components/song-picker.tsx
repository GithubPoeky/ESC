import { useMemo, useState } from 'react'
import { Plus, Search, X } from 'lucide-react'

import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { Flag } from '@/components/flag'
import type { Song } from './song-dialog'

/**
 * Searchable list of library songs for one start number.
 * Songs already used elsewhere in the same year are listed first.
 */
export function SongPicker({
  songs,
  usedInYear,
  selectedId,
  onSelect,
  onCreate,
  children,
}: {
  songs: Song[]
  usedInYear: Set<number>
  selectedId: number | null
  onSelect: (songId: number | null) => void
  onCreate: (query: string) => void
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    const matches = songs.filter(
      (s) =>
        !q ||
        s.title.toLowerCase().includes(q) ||
        s.artist.toLowerCase().includes(q) ||
        s.country.toLowerCase().includes(q),
    )
    return [...matches].sort(
      (a, b) => Number(usedInYear.has(b.id)) - Number(usedInYear.has(a.id)),
    )
  }, [songs, query, usedInYear])

  const choose = (id: number | null) => {
    onSelect(id)
    setOpen(false)
    setQuery('')
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>{children}</PopoverTrigger>
      <PopoverContent align="start" className="w-80 p-0">
        <div className="relative border-b">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            autoFocus
            aria-label="Search songs"
            placeholder="Search title, artist or country"
            className="h-11 rounded-none border-0 bg-transparent pl-9 shadow-none focus-visible:ring-0 dark:bg-transparent"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <ul className="max-h-72 overflow-y-auto p-1" role="listbox">
          {results.length === 0 && (
            <li className="px-3 py-6 text-center text-sm text-muted-foreground">
              {songs.length === 0
                ? 'The song library is empty.'
                : 'No matching songs.'}
            </li>
          )}
          {results.map((s) => (
            <li key={s.id}>
              <button
                type="button"
                role="option"
                aria-selected={s.id === selectedId}
                onClick={() => choose(s.id)}
                className="flex w-full items-center gap-3 rounded-md px-2 py-2 text-left text-sm hover:bg-accent focus-visible:bg-accent focus-visible:outline-none aria-selected:bg-primary/20"
              >
                <Flag country={s.country} className="h-5" />
                <span className="min-w-0 flex-1">
                  <span className="block truncate font-semibold">{s.title}</span>
                  <span className="block truncate text-xs text-muted-foreground">
                    {s.artist} · {s.country}
                  </span>
                </span>
                {usedInYear.has(s.id) && s.id !== selectedId && (
                  <span className="rounded-full bg-cyan/15 px-2 py-0.5 text-[0.65rem] font-semibold text-cyan">
                    this year
                  </span>
                )}
              </button>
            </li>
          ))}
        </ul>
        <div className="flex gap-2 border-t p-2">
          <Button
            size="sm"
            className="flex-1"
            onClick={() => {
              setOpen(false)
              onCreate(query.trim())
              setQuery('')
            }}
          >
            <Plus /> New song
          </Button>
          {selectedId != null && (
            <Button size="sm" variant="ghost" onClick={() => choose(null)}>
              <X /> Clear slot
            </Button>
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
