import { useEffect, useState } from 'react'
import { toast } from 'sonner'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Flag } from '@/components/flag'
import { COUNTRIES } from '@/lib/countries'
import { createSong, updateSong } from '@/lib/eurovision.functions'

export type SongValues = { title: string; artist: string; country: string }
export type Song = SongValues & { id: number }

const empty: SongValues = { title: '', artist: '', country: '' }

export function SongDialog({
  open,
  onOpenChange,
  song,
  initial,
  onSaved,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  /** Pass an existing song to edit it; omit to create a new one. */
  song?: Song | null
  initial?: Partial<SongValues>
  onSaved: (song: Song) => void | Promise<void>
}) {
  const [values, setValues] = useState<SongValues>(empty)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    if (open) setValues(song ?? { ...empty, ...initial })
    // Reset only when the dialog opens, not while the user is typing.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open])

  const set = (key: keyof SongValues) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setValues((v) => ({ ...v, [key]: e.target.value }))

  const valid =
    values.title.trim() && values.artist.trim() && values.country.trim()

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!valid) return
    setSaving(true)
    try {
      const data = {
        title: values.title.trim(),
        artist: values.artist.trim(),
        country: values.country.trim(),
      }
      if (song) {
        await updateSong({ data: { ...data, id: song.id } })
        await onSaved({ ...data, id: song.id })
      } else {
        const created = await createSong({ data })
        await onSaved(created)
      }
      onOpenChange(false)
      toast.success(song ? 'Song updated' : 'Song added to the library')
    } catch {
      toast.error('Could not save the song')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{song ? 'Edit song' : 'New song'}</DialogTitle>
          <DialogDescription>
            Songs live in the library and can be picked for any start number.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="grid gap-4">
          <div className="grid gap-2">
            <Label htmlFor="song-country">Country</Label>
            <div className="relative">
              <span className="pointer-events-none absolute top-1/2 left-3 flex -translate-y-1/2">
                <Flag country={values.country} className="h-4" />
              </span>
              <Input
                id="song-country"
                list="esc-countries"
                className="pl-10"
                placeholder="Sweden"
                autoComplete="off"
                value={values.country}
                onChange={set('country')}
                required
              />
            </div>
            <datalist id="esc-countries">
              {COUNTRIES.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="song-title">Song title</Label>
            <Input
              id="song-title"
              placeholder="Euphoria"
              value={values.title}
              onChange={set('title')}
              required
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="song-artist">Artist</Label>
            <Input
              id="song-artist"
              placeholder="Loreen"
              value={values.artist}
              onChange={set('artist')}
              required
            />
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={!valid || saving}>
              {saving ? 'Saving…' : song ? 'Save changes' : 'Add song'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
