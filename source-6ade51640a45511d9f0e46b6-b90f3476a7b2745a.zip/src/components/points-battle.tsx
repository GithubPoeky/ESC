import { useState } from 'react'
import { Crown, Target } from 'lucide-react'
import { toast } from 'sonner'

import { Flag } from '@/components/flag'
import { PlaceInput } from '@/components/place-input'
import { RaterAvatar } from '@/components/site-header'
import { setFinalPlace, setPrediction } from '@/lib/eurovision.functions'
import { useRaters } from '@/lib/rater'
import { cn } from '@/lib/utils'

type BattleEntry = {
  id: number
  startNumber: number
  finalPlace: number | null
  song: { id: number; title: string; artist: string; country: string } | null
  predictions: { raterId: number; place: number }[]
}

/**
 * Points battle for the Grand Final: everyone predicts each country's
 * finishing place; each entry costs |predicted − actual| points.
 * Fewest points wins.
 */
export function PointsBattle({
  entries,
  onChange,
}: {
  entries: BattleEntry[]
  onChange: () => Promise<void>
}) {
  const { raters } = useRaters()
  const rows = entries.filter((e) => e.song)
  const places = rows.length

  // Default to whoever has already predicted, otherwise the first two jurors.
  const [battlerIds, setBattlerIds] = useState<number[]>(() => {
    const predicted = raters
      .filter((r) => rows.some((e) => e.predictions.some((p) => p.raterId === r.id)))
      .map((r) => r.id)
    return predicted.length ? predicted : raters.slice(0, 2).map((r) => r.id)
  })
  const battlers = raters.filter((r) => battlerIds.includes(r.id))

  const toggle = (id: number) =>
    setBattlerIds((ids) =>
      ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id],
    )

  const predictionOf = (e: BattleEntry, raterId: number) =>
    e.predictions.find((p) => p.raterId === raterId)?.place ?? null

  const resultsIn = rows.filter((e) => e.finalPlace != null).length
  const standings = battlers
    .map((r) => {
      let points = 0
      let counted = 0
      for (const e of rows) {
        const guess = predictionOf(e, r.id)
        if (guess == null || e.finalPlace == null) continue
        points += Math.abs(guess - e.finalPlace)
        counted++
      }
      const predicted = rows.filter((e) => predictionOf(e, r.id) != null).length
      return { rater: r, points, counted, predicted }
    })
    .sort((a, b) => a.points - b.points)
  const best = standings[0]?.points
  const leaders =
    resultsIn > 0 && standings.length > 1 && standings.some((s) => s.points !== best)
      ? new Set(standings.filter((s) => s.points === best).map((s) => s.rater.id))
      : new Set<number>()

  const save = async (fn: () => Promise<unknown>) => {
    try {
      await fn()
      await onChange()
    } catch {
      toast.error('Could not save the place')
    }
  }

  if (raters.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-muted-foreground">
        Add your jury from the menu in the top corner to start a points battle.
      </div>
    )
  }
  if (rows.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-muted-foreground">
        Pick songs for the Grand Final start numbers to start a points battle.
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border bg-card p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-lg font-bold">Points battle</h3>
            <p className="mt-1 max-w-reading text-sm text-muted-foreground">
              Before the final, everyone predicts each country's place. Once
              the results are in, every place you're off costs a point.
              Fewest points wins.
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5" role="group" aria-label="Who's battling">
            {raters.map((r) => (
              <button
                key={r.id}
                type="button"
                aria-pressed={battlerIds.includes(r.id)}
                onClick={() => toggle(r.id)}
                className={cn(
                  'flex items-center gap-1.5 rounded-full border py-1 pr-3 pl-1 text-sm font-semibold transition-colors motion-reduce:transition-none',
                  battlerIds.includes(r.id)
                    ? 'border-primary bg-primary/15 text-foreground'
                    : 'text-muted-foreground opacity-70 hover:opacity-100',
                )}
              >
                <RaterAvatar rater={r} className="size-6 text-[0.6rem]" />
                {r.name}
              </button>
            ))}
          </div>
        </div>

        {battlers.length > 0 && (
          <ol className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {standings.map(({ rater, points, counted, predicted }) => {
              const leading = leaders.has(rater.id)
              return (
                <li
                  key={rater.id}
                  className={cn(
                    'flex items-center gap-3 rounded-xl border bg-background/40 p-3',
                    leading && 'border-gold/60 shadow-[0_0_32px_-12px_var(--gold)]',
                  )}
                >
                  <RaterAvatar rater={rater} className="size-9 text-xs" />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-1.5 truncate font-bold">
                      {rater.name}
                      {leading && <Crown aria-label="Winning" className="size-4 text-gold" />}
                    </span>
                    <span className="block text-xs text-muted-foreground">
                      {resultsIn
                        ? `${counted} of ${places} scored`
                        : `${predicted} of ${places} predicted`}
                    </span>
                  </span>
                  <span className="text-right">
                    <span className="block font-display text-2xl leading-none font-black">
                      {resultsIn ? points : '–'}
                    </span>
                    <span className="text-[0.6rem] tracking-wider text-muted-foreground uppercase">
                      points
                    </span>
                  </span>
                </li>
              )
            })}
          </ol>
        )}
      </div>

      <div className="overflow-x-auto rounded-2xl border bg-card">
        <table className="w-full min-w-[34rem] text-sm">
          <thead>
            <tr className="border-b text-left text-xs tracking-wider text-muted-foreground uppercase">
              <th className="p-3 font-semibold">Country</th>
              {battlers.map((r) => (
                <th key={r.id} className="p-3 text-center font-semibold">
                  <span className="inline-flex items-center gap-1.5">
                    <RaterAvatar rater={r} className="size-5 text-[0.55rem]" />
                    {r.name}
                  </span>
                </th>
              ))}
              <th className="p-3 text-center font-semibold text-gold">Result</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id} className="border-b last:border-0">
                <td className="p-3">
                  <span className="flex items-center gap-3">
                    <span className="w-6 shrink-0 text-right font-display text-xs font-bold text-muted-foreground">
                      {String(e.startNumber).padStart(2, '0')}
                    </span>
                    <Flag country={e.song!.country} className="h-5" />
                    <span className="min-w-0">
                      <span className="block truncate font-bold">{e.song!.country}</span>
                      <span className="block truncate text-xs text-muted-foreground">
                        {e.song!.title}
                      </span>
                    </span>
                  </span>
                </td>
                {battlers.map((r) => {
                  const guess = predictionOf(e, r.id)
                  const clash =
                    guess != null &&
                    rows.some((o) => o.id !== e.id && predictionOf(o, r.id) === guess)
                  const diff =
                    guess != null && e.finalPlace != null
                      ? Math.abs(guess - e.finalPlace)
                      : null
                  return (
                    <td key={r.id} className="p-3 text-center">
                      <span className="inline-flex items-center gap-2">
                        <PlaceInput
                          value={guess}
                          max={places}
                          label={`${r.name}'s predicted place for ${e.song!.country}`}
                          warning={clash ? `${r.name} has place ${guess} twice` : undefined}
                          onSave={(place) =>
                            save(() =>
                              setPrediction({ data: { entryId: e.id, raterId: r.id, place } }),
                            )
                          }
                        />
                        <span
                          className={cn(
                            'w-7 text-left font-display text-xs font-bold',
                            diff === 0 ? 'text-gold' : 'text-muted-foreground',
                          )}
                          aria-label={diff == null ? undefined : `${diff} points`}
                        >
                          {diff == null ? '' : diff === 0 ? <Target className="size-4" /> : `+${diff}`}
                        </span>
                      </span>
                    </td>
                  )
                })}
                <td className="p-3 text-center">
                  <PlaceInput
                    value={e.finalPlace}
                    max={places}
                    label={`Actual place for ${e.song!.country}`}
                    warning={
                      e.finalPlace != null &&
                      rows.some((o) => o.id !== e.id && o.finalPlace === e.finalPlace)
                        ? `Place ${e.finalPlace} is used twice`
                        : undefined
                    }
                    className="border-gold/50"
                    onSave={(place) =>
                      save(() => setFinalPlace({ data: { entryId: e.id, place } }))
                    }
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
