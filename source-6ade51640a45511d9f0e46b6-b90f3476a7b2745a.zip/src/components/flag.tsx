import { flagCode } from '@/lib/countries'
import { cn } from '@/lib/utils'

/**
 * Country flag as an image (emoji flags don't render on Windows).
 * Size it with a height class; the width follows the 4:3 ratio.
 */
export function Flag({
  country,
  className,
}: {
  country: string
  className?: string
}) {
  const code = flagCode(country)
  if (!code) {
    return (
      <span
        aria-hidden
        className={cn('inline-block aspect-[4/3] h-6 shrink-0 rounded-[3px] bg-muted', className)}
      />
    )
  }
  return (
    <img
      src={`/flags/${code}.svg`}
      alt=""
      aria-hidden
      loading="lazy"
      className={cn(
        'inline-block aspect-[4/3] h-6 shrink-0 rounded-[3px] object-cover ring-1 ring-white/10',
        className,
      )}
    />
  )
}
